# Issue 269 slice B store handoff

Commit: `1234ce9596998129c4eb59092a544117d893e8ff`, based on `8ba2c2e4` in `C:/Users/Q/code/barn-269-b`.

## Implemented boundary

`Store.CaptureCheckpoint(roots) *CheckpointCapture` briefly owns the exclusive commit gate and store write lock, calls the same registered timestamp constructor as `BeginSnapshot`, captures max/high-water bounds and immutable segment-list membership, copies pending/task root slices, and owns copies of every anonymous object. A publication-maintained `directoryAnonymous` index covers rare directory-backed anonymous fixtures without scanning numbered objects at capture.

`capture.Materialize() (Snapshot, SnapshotValueRewriter, error)` releases those locks before any numbered object/property/ancestry walk. It resolves numbered images through the registered snapshot, reads WAIF images at that same timestamp, uses that graph for anonymous reachability and task/pending ownership, memoizes before recursive rewrite to preserve cycles and sharing, and preserves map insertion order. Ancestry resolution excludes objects invalid at the captured timestamp. Supplied external roots are eagerly frozen; the returned rewriter therefore remains valid after Close.

`capture.Close()` is idempotent, deregisters retention and clears source object/root/anonymous/segment references. Materialize drops its source WAIF-image cache once the detached graph is complete. Unknown WAIFs introduced into a sealed rewriter panic instead of consulting live state; foreign/missing timestamp images return explicit Materialize errors. Existing `Snapshot`/`SnapshotWithRoots` convenience signatures use this same path and panic contextually on impossible materialization errors. The old live snapshot graph/ownership walkers were removed.

Root supplied a fixture repair in `db/format/checkpoint_recovery_test.go`: independent stores now use independent payloads with the same expected WAIF identity. The previous shared payload became foreign to the second store when snapshot resolution correctly attached its first store clock. Foreign-domain rejection remains explicitly tested.

## Raw TDD and validation output

Initial `go test ./db/store -run '^TestCheckpointCapture' -count=1`:

```text
checkpoint_capture_test.go:20:9: s.CaptureCheckpoint undefined (type *Store has no field or method CaptureCheckpoint)
checkpoint_capture_test.go:44:9: s.CaptureCheckpoint undefined (type *Store has no field or method CaptureCheckpoint)
FAIL github.com/MongooseMoo/barn/db/store [build failed]
```

After implementation, the same command:

```text
ok github.com/MongooseMoo/barn/db/store 0.989s
```

Full `go test ./db/store ./db/format -count=1` after refactoring:

```text
ok github.com/MongooseMoo/barn/db/store 3.358s
ok github.com/MongooseMoo/barn/db/format 4.996s
```

`go test -race ./db/store ./db/format -count=1`:

```text
ok github.com/MongooseMoo/barn/db/store 8.887s
ok github.com/MongooseMoo/barn/db/format 7.693s
```

Final `go test -race ./db/store -run '^TestCheckpoint' -count=1`, after final ancestry/source-release cleanup:

```text
ok github.com/MongooseMoo/barn/db/store 1.980s
```

All successful commands exited zero. `git diff --check` produced no output. Existing atomic-boundary regression remains intact. Added deterministic held-materialization tests prove ordinary multi-object commits and coarse writes finish while the walk is held, then assert captured conservation. Additional tests cover directory growth/max bounds, reparent/definition order/reciprocity, historical WAIF/anonymous mutation and recycle, map keys, dangling anonymous references, task/pending overlap, cycles/aliases, pending-only capture followed by collection maintenance, 20 later commits plus post-Close history pruning, foreign image errors and no leaked timestamp floor.

## Remaining integration work

Root owns format/server capture-before-resume integration, persisted/reloaded graph and baseline-byte verification, real server stage responsiveness, pinned Elle evidence, documented managed conformance and paired Mongoose latency/memory evidence. These Go/race results establish no Elle, conformance, production liveness or performance verdict.
