# Checkpoint Elle plan objection

Current status: the objections below were resolved with explicit root approval, implementation is complete, and final queue-source validation passed. Earlier pending/STOP statements are retained as the investigation history; the final evidence is recorded at the end.

Final owned implementation commit: `c110c915c5973af578da1a13cb51489f041ff11f`. Index was empty after that scoped commit; root-owned files remain unstaged.

The approved portable serialize/reload read currently fails before producing a checkpoint read transaction. Existing `elleWorld` builds properties with `ObjectBuilder.SetProperty` while leaving `PropDefsCount` zero. Those in-memory fixtures work for live MOO reads, but a portable dump stores property values against actual propdef names; no local definition names are emitted for those zero-count fixture properties. Reload therefore loses the `data` name, and the first reloaded `#11.data` read raises native `E_PROPNF`.

Exact command from `C:/Users/Q/code/barn-269-b` (WSL Debian cwd `/mnt/c/Users/Q/code/barn-269-b`):

```text
BARN_ELLE_OUTPUT="$PWD/.tmp/269-elle-checkpoint-red" BARN_ELLE_FAULT=checkpoint-live-reads BARN_ELLE_ROUNDS=8 GOMAXPROCS=4 go test -tags elle ./engine -run '^TestElleIsolationHistories$' -count=1 -v -timeout=5m
```

Raw failure retained in `.tmp/269-elle-checkpoint-red-go.log` and emitted history/manifest in `.tmp/269-elle-checkpoint-red`:

```text
task 100049 native error E_PROPNF
SourceLine:if (kind == 0) return o.data;
list-append ... paths=map[checkpoint_capture:1 checkpoint_writer_overlap:1 ...]
--- FAIL: TestElleIsolationHistories (2.08s)
FAIL github.com/MongooseMoo/barn/engine 2.089s
```

The new held probe and reload runtime path are present; the deliberate live-read fault is not yet wired, so no negative-control verdict is claimed. Existing native errors remain visible. No format/reader/store semantic workaround has been made.

Proposed narrow plan correction: make the existing Elle fixture persistable by setting each builder's actual local property definition count and canonical order before ingestion (or construct those definitions through production `DefineProperty`), retaining identical row values, verb code, and MOO assertions. Also explicitly set detached fixture locations to `ObjNothing` where they represent no location, to avoid unrelated startup repair of default-zero fixture locations. Root approval is required before deviating from the mandated unchanged fixture plan. After approval, rerun healthy and absent-fault RED, then implement the one deliberate live-numbered-image fault and demand pinned Elle rejection.

## Approved metadata correction and second observed fixture defect

Root approved the narrow metadata/location repair while requiring inherited overrides/clear slots to remain inherited. With local counts/order and detached locations corrected, `TestElleCheckpointFixtureRoundTrip` passed (`ok engine 2.404s`). Full no-fault-effect generation then completed (`ok engine 2.084s`), but pinned Elle correctly rejected its persisted read: `.tmp/269-elle-checkpoint-absent-fault/list-append.edn false`. That path retains the full raw Go log, history, manifest and `graphs-list-append/G-single-item.txt` witness. No `checkpoint-live-reads` branch is implemented yet, so this rejection is not negative-control success.

The persisted transaction reads property `[1 2 100 101 102 103 190 195]` but inherited-property `[]`, although the pre-capture inherited row held `[15 16 191 196]`. The fixture's #18 has a local `data` definition and is later parented to #0, which independently defines `data`; this duplicate ancestry definition is not a valid representation of the intended inherited override. Requested correction: mark #18.data as an inherited override and exclude it from #18's local definition count/order, keeping its existing value and the child clear inherited slot. Root confirmation is pending before that additional fixture metadata correction.

## Approved inherited-override correction and meaningful control

Root subsequently approved the #18 metadata correction and required an all-row preflight before concurrency. The new preflight compares every normalized MOO row in the original and reloaded worlds, using the same existing `read_row`/register expressions; a standalone regression first writes two nonempty tokens to every append row. It failed before the correction with identical rows except inherited-property `{114,115}` becoming `{}` (`FAIL engine 2.281s`). Setting only #18.data's definition metadata to inherited, preserving its value/owner/perms/clear status, made the regression pass (`ok engine 2.284s`). Runtime-created inherited and clear slots remain untouched.

The absent-fault-effect control was then repeated through the exact held/capture/write/reload/MOO-read path. Raw `.tmp/269-elle-checkpoint-control-go.log` ends `ok engine 2.112s`, and pinned CLI output is `/mnt/c/Users/Q/code/barn-269-b/.tmp/269-elle-checkpoint-control/list-append.edn true`. This provides the healthy control the previous invalid fixture could not supply. Only afterward was `checkpoint-live-reads` implemented in the checker-only branch. The full default pinned driver is running in `.tmp/269-elle-checkpoint-full`; final verdicts remain pending until its terminal result.

## Initial full checker and approved anonymous-stack repair

That initial full checker completed successfully: `results.json` reports `errors=0 verdicts=16`, with all six healthy model verdicts true and all ten append-fault verdicts false. The new checkpoint fault's `G-single-item.txt` specifically shows a reloaded transaction missing the writer's property token 197 while observing its inherited-property token 198, a two-transaction contradiction. Raw histories, manifests, logs and witnesses remain under `.tmp/269-elle-checkpoint-full`.

Before publication, analyst review identified that the new anonymous-object recursion could exhaust stack on a flat object chain. Root approved replacing only anonymous graph expansion with an explicit work queue, retaining recursive traversal of shallow MOO values/WAIF images and the same timestamp/visited semantics. The subprocess regression constructs 2000 anonymous objects before applying a 128 KiB Go stack limit in the disposable child. Original recursive code produced `runtime: goroutine stack exceeds 131072-byte limit`, `fatal error: stack overflow`, child exit 2 and test exit 1 (`.tmp/269-capture-stack-red.log`). The queue implementation passed (`ok store 1.314s`, `.tmp/269-capture-stack-green.log`) and captures all 2000 objects without a leaked timestamp floor.

The production repair justifies rerunning the entire default pinned checker. That final rerun is in `.tmp/269-elle-checkpoint-queue-final`; verdicts remain pending until terminal completion. Targeted final queue race output is retained in `.tmp/269-capture-queue-race.log`: `queue_race_exit=0`, `ok store 3.186s`, `ok engine 3.533s` for `go test -race ./db/store ./engine -run '^(TestCheckpoint|TestElleCheckpointFixtureRoundTrip)' -count=1`.

## Final queue-source verdicts and handoff

The full default pinned driver completed on the repaired queue source with exit zero. `.tmp/269-elle-checkpoint-queue-final/results.json` reports `final_errors=0 final_verdicts=16`: six healthy model verdicts `true` for seeds 412/395/396, 40 rounds each, and ten append-fault verdicts `false` with witnesses. The CLI source is pinned at `9c2a18b3719f573dab06ae05c955c9c9d5225673`; this authorized local run used `/opt/java/25/bin/java`, with CI's Java 21 run remaining authoritative for that environment. Exact command from the WSL Debian checkout:

```text
python3 scripts/check_elle.py --jar /tmp/barn-elle-cli-269/target/elle-cli-0.1.11-standalone.jar --java /opt/java/25/bin/java --output "$PWD/.tmp/269-elle-checkpoint-queue-final"
```

The final new-fault witness at `fault-checkpoint-live-reads/graphs-list-append/G-single-item.txt` states:

```text
T1 < T2, because T1 did not observe T2's append of 197 to "property".
However, T2 < T1, because T1 observed T2's append of 198 to key "inherited-property": a contradiction!
```

Seed 412 manifest counts, required separately within each model:

```text
list-append capture=12 overlap=41 reload=12 row_count=11 row_min=12
rw-register capture=11 overlap=40 reload=11 row_count=3 row_min=11
```

The final queue-source race results above remain current. A full store run also passed (`queue_store_exit=0`, `ok store 3.587s`, `.tmp/269-capture-queue-store.log`). Driver unit tests passed all three cases. `git diff --check` produced no output.

Root subsequently supplied `server/checkpoint_materialize_elle_test.go`. The script now runs it as a preflight, retains `server-materialization-go.log`, records its command/exit in `results.json`, and reports/fails any nonzero exit while still retaining the other histories. Because that integration arrived after the final full driver had started, root approved validating the exact preflight separately instead of repeating all sixteen already-completed verdicts. Its raw log is retained inside the final output directory and ends:

```text
--- PASS: TestCheckpointMaterializationAllowsRuntimeCommit (0.05s)
    --- PASS: TestCheckpointMaterializationAllowsRuntimeCommit/ordinary (0.03s)
    --- PASS: TestCheckpointMaterializationAllowsRuntimeCommit/coarse (0.03s)
PASS
ok github.com/MongooseMoo/barn/server 0.061s
```

CI will execute the integrated script and root-owned server preflight together. Root retains `engine/admission.go`, all three server test files, publication, final CI/merge, and workload measurements. This worker's commit is limited to `db/store/checkpoint_capture.go`, `db/store/checkpoint_capture_stack_test.go`, `engine/elle_workload_test.go`, `scripts/check_elle.py`, and `docs/elle-isolation.md`. This evidence gives bounded persisted checkpoint isolation coverage; it gives no performance or managed MOO conformance verdict.
