# Issue 269 slice B independent analysis

Reviewed committed head `05bebd88a6365a57f38845fe8c476bac49e51094` plus the live checkpoint capture probe edits while the Elle worker was active. Source changes remain owned by the other workers. This report is analysis, not a merge approval.

## Follow-up: both analysis items resolved in live source

The P2 below is cleared by the explicit anonymous-object queue in `checkpoint_capture.go:120-133`. `visitValue` stops at anonymous references, records them once and enqueues them; only the outer loop resolves their properties. Anonymous graph length no longer adds traversal frames. WAIF/list/map value traversal retains its earlier recursion behavior. The new subprocess regression builds 2,000 anonymous objects with a single anonymous reference per object and applies a 128 KiB stack limit only to that disposable process. The preserved red log demonstrates that the previous code exhausted this limit; the green log demonstrates complete traversal after repair.

The server evidence gap is cleared by `server/checkpoint_materialize_elle_test.go:21`. It holds the actual store capture pause immediately after numbered object #0 is copied, executes an admitted runtime task that changes both #0 and #1 (and adds a verb for the coarse case), checks both live values before release, then reloads the portable checkpoint and checks both old values plus exclusion of the new verb. The test uses the existing Elle-only pause hook and does not add a public debug API.

Raw preserved output inspected for this follow-up:

```text
.tmp/269-capture-stack-red.log:
runtime: goroutine stack exceeds 131072-byte limit
fatal error: stack overflow
--- FAIL: TestCheckpointCaptureAnonymousChainUsesBoundedStack (0.34s)

.tmp/269-capture-stack-green.log:
--- PASS: TestCheckpointCaptureAnonymousChainUsesBoundedStack (0.36s)
PASS
ok github.com/MongooseMoo/barn/db/store 1.314s

.tmp/269-server-materialize.log:
--- PASS: TestCheckpointMaterializationAllowsRuntimeCommit (0.06s)
    --- PASS: TestCheckpointMaterializationAllowsRuntimeCommit/ordinary (0.03s)
    --- PASS: TestCheckpointMaterializationAllowsRuntimeCommit/coarse (0.03s)
PASS
ok github.com/MongooseMoo/barn/server 0.065s
```

No unresolved concrete code blocker remains from this analysis. No heavy gate was rerun during follow-up; the pinned Elle, managed conformance, full race, final-head CI and performance/memory acceptance verdicts remain owned by root/verifier. This is not merge approval.

## Historical finding: anonymous reachability consumed stack proportional to object graph depth

**P2, resource regression.** `db/store/checkpoint_capture.go:120-135` follows an anonymous value by resolving its object and recursively calling `visit` on each property. A chain of anonymous objects with one scalar anonymous reference per object therefore adds one Go frame per object. No container nesting or inheritance depth is required. The previous anonymous serialization planner expanded anonymous objects through an explicit queue; the existing `store_reachability.go:202-223` still demonstrates that queue-based pattern.

The visited set terminates cycles but does not bound an acyclic chain's depth. This changes checkpoint stack demand from bounded traversal state to O(anonymous graph depth), adding stack-memory amplification and eventual Go stack exhaustion for sufficiently deep graphs. I have not executed a process-crashing depth probe and make no claim about a measured failure threshold. The current cycle/alias tests do not exercise a long chain. Use an explicit work stack/queue for anonymous traversal and a regression with a long anonymous-only chain (no deep list or parent tree).

Raw live source search:

```text
120:func (p *anonSerializationPlan) visit(v types.Value, anon map[types.ObjID]struct{}, waifs map[types.WaifIdentity]struct{}, resolve func(types.ObjID) *Object) {
134:                p.visit(prop.value, anon, waifs, resolve)
202:func (s *Store) expandAnonymousReachabilityLocked(reachable map[types.ObjID]struct{}, queue []types.ObjID, retained bool) {
203:    for len(queue) > 0 {
```

## Evidence gap reported to root

`server/input_admission_test.go:229` holds the Serialize entry before calling the real format serializer; the store held-walk test uses StoreTxn writers. Their composition supports the intended boundary, but a single test that holds the actual store materialization and observes an admitted runtime task commit is needed for the issue's literal server-stage acceptance claim. Root has taken ownership of a dedicated Elle-build server test using the existing internal pause hook. Its outcome is not part of this analysis.

## Other cross-boundary observations

No additional concrete defect was found in the reviewed Capture -> Serialize -> Publish flow. Task persistence roots use the same traversal for seeding and rewriting; the production task snapshot clones VM slices/program constants/continuations before admission resumes. Anonymous objects are owned copies, numbered objects use the registered timestamp, and the same WAIF image resolver and rewrite memo serve task/pending/store graphs. Materialization errors release the capture; successful serialization releases history before the file writer. Terminal publication retains the runtime barrier. Existing staged file publication and error/hook tests were inspected rather than re-run as competing gates.

The capture pause still copies every anonymous object, including its properties, relationships and verb code, while admission/store publication are excluded. The issue explicitly permits this initial representation, but the measurements must include nontrivial anonymous graphs; ordinary numbered-only fixtures cannot establish a capture-pause budget.

## Independent bounded check

```text
go test ./task -run '^TestTransformPersistenceValuesMatchesQueuedAndSuspendedWriterSurfaces$' -count=1
ok github.com/MongooseMoo/barn/task 0.998s
exit_code=0
```

No full race, managed conformance, Mongoose performance or pinned Elle verdict is established by this report. Root owns those evidence runs and the final exact-head verification.
