# Checkpoint experiment acceptance budgets

Declared after the first baseline and before any candidate measurement, 2026-10-17.
Baseline source f688c38acab4f6cac795d6615895a6c5443dd54f plus the identical opt-in measurement harness.
Fixture SHA-256 885a55c4bc28151760f648977b090cc73c8b7cff9ac4228f4b38355dc5e3d1c7 (196847159 bytes).
Initial ordinary baseline dump/writer maxima: 6481.918/6481.130, 8008.071/8007.046, 7142.000/7141.316 ms; zero wholly enclosed completed writes in all three.

- Each ordinary and coarse writer candidate trial must have maximum end-to-end writer latency <= 50 percent of its corresponding paired baseline trial, and at least ten completed writer evaluations wholly inside the checkpoint interval.
- Every writer result and checkpoint must succeed; dump reload must recover the captured probe value. Retain failed cohorts and diagnose before claiming improvement.
- Quiescent portable Mongoose dumps from the unchanged source state must have identical bytes; sidecar identity semantics have separate tests.
- Post-GC live heap must be <= 120 percent of the corresponding baseline. Process peak RSS, measured for equivalent runs with /usr/bin/time -v, must be <= 150 percent of baseline; process RSS includes loading, canonical serialization and reload and is not a checkpoint-only attribution.
- Retained read registrations must settle to baseline after the writer stops. Report numbered history entries honestly: releasing a capture only makes old numbered images eligible for pruning, which occurs on subsequent writes.
- Preserve raw per-command start/end/durations, checkpoint logs, source/harness/fixture hashes, host/Go configuration and terminal test verdicts. Use alternating baseline/candidate blocks after initial baseline establishment.

This experiment uses admitted synthetic ordinary or anonymous/coarse writers against the real Mongoose object graph and three synthetic future fork tasks. It intentionally does not run the fixture's live world simulation, network clients or sound catalog. It establishes controlled checkpoint responsiveness, not gameplay goodput or production latency. No race/profiling instrumentation is enabled during latency runs.
